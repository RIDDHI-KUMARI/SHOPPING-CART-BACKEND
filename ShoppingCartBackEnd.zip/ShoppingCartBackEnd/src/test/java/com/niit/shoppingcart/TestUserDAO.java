package com.niit.shoppingcart;

import junit.framework.TestCase;

public class TestUserDAO extends TestCase {

}
